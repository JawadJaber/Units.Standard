﻿namespace Units.Standard
{
    public interface ICoilLength
    {
        double ValueInInch { get; set; }
        double ValueInMM { get; set; }
        double ValueInM { get; set; }


    }
}
