﻿namespace Units.Standard
{
    public interface IFinsSpacing
    {
        double ValueInFPI { get; set; }
        double ValueInFPMM { get; set; }
        double ValueInFPM { get; set; }
    }
}
